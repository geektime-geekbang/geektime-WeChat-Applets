# 更新日志

## 1.0.0

- 更新`weui-wxss`到`2.3.0`版本，支持 DarkMode
- Demo 支持 DarkMode