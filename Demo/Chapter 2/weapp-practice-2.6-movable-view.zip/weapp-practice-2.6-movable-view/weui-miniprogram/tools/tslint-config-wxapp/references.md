TSLint rules: https://palantir.github.io/tslint/rules/

TSLint repo: https://github.com/palantir/tslint

tslint:recommended: https://github.com/palantir/tslint/blob/master/src/configs/recommended.ts

