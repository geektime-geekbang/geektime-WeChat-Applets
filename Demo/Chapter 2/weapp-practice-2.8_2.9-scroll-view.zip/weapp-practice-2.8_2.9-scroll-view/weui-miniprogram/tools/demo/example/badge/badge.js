import CustomPage from '../../base/CustomPage'

CustomPage({})