module.exports = require('./tslintrc')
